package Persistence;

import java.io.Serializable;

import Logic.Concurso;
import Logic.Participantes;

public class PersistenceStructuresManagement implements Serializable {

	private static final long serialVersionUID = 1L;

	private Concurso concurso;
	private Participantes participantes;

	public PersistenceStructuresManagement() {
	}

	public PersistenceStructuresManagement(Concurso c, Participantes pp) {

		concurso = c;
		participantes = pp;

	}

	public Concurso getConcurso() {
		return concurso;
	}

	public void setConcurso(Concurso concurso) {
		this.concurso = concurso;
	}

	public Participantes getParticipantes() {
		return participantes;
	}

	public void setParticipantes(Participantes participantes) {
		this.participantes = participantes;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
