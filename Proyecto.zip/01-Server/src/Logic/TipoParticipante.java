package Logic;

public enum TipoParticipante {
	NACIONAL, EXTRANJERO
}
