package OldTestView;

public class Principal {

	public static void main(String[] args) {
		VentanaFoto ven = new VentanaFoto();
		ven.visualizar();
	}

}
